<?php

    echo $json;

?>