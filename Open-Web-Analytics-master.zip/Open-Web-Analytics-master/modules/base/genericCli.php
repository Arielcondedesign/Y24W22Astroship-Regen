<?php
		
require_once(OWA_DIR.'owa_view.php');
	
class owa_genericCliView extends owa_cliView {
	

}	
	
?>