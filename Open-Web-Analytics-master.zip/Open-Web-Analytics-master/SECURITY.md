# Security Policy

## Supported Versions

Currently we are only supporting security updates to the following versions of OWA Server:

| Version | Supported          |
| ------- | ------------------ |
| 1.7.x   | :white_check_mark: |

## Reporting a Vulnerability

Please report all security issues to: security@openwebanalytics.com
